%% Controllability of complex networks demo:


% Examples 1, 2 and 3 are three different network configurations illustrated
% in Figure 1 of Liu et al, Controllability of complex networks, Nature
% 2011

%% Example 1:
% Directed path, 4 nodes. Node 1 connects to node 2, node 2 connects to
% node 3, node 3 connects to node 4
clc
A = [0 1 0 0;
     0 0 1 0;
     0 0 0 1;
     0 0 0 0];
[Nd, drivernodes,Nconfig] = ExactControllability(A,'plotting',1)
% The above command returns Nd = 1, i.e. total of 1 driver node,
% drivernodes = 1, i.e. node #1 is the driver node
% Nconfig = 1, i.e. there is only 1 configuration of driver node

%% Example 2:
% Directed star. 4 nodes, where node 1 connects to all other 3 nodes.
clc
A = [0 1 1 1;
    0 0 0 0;
    0 0 0 0;
    0 0 0 0;];
[Nd, drivernodes,Nconfig] = ExactControllability(A,'plotting',1)
% In this example, there are total of 3 driver nodes, Nd = 3.
% The identity of driver nodes are provided in the vector drivernodes.
% There are total of 3 distinct configurations of selecting drivernodes,
% Nconfig = 3. Each time the algorithm is run, a different set of
% drivernodes will be returned. The possibilites are: {1,3,4}, {1,2,3},
% {1,2,4}

%% Example 3:
clc
A = [0 1 1 1 1 1;
    0 0 0 0 0 0;
    0 0 0 0 0 0;
    0 0 0 0 0 0;
    0 0 0 0 0 0;
    0 0 0 0 1 0;];
[Nd, drivernodes,Nconfig] = ExactControllability(A,'plotting',1)
% In this example, there are Nd = 4 driver nodes and 4 distinct
% configurations. The possiblities of drivernodes = {1,2,3,4}, {1,3,4,6},
% {1,2,3,6}, {1,2,4,6}

%% Example 4:
% Let's try a more complex network. Let's build a scale-free directed
% network with 300 nodes, using a seed network size of 10 nodes and average
% connectivity 10. Please see the accompanying BAgraph_dir.m file for more
% info on the algorithm. The BAgraph_dir algorithm may take some time to
% generate an adjacency matrix. To save time, you may load a sample
% adjacency matrix by executing: 

%load('scalefree_adjacency.mat');
clc
A = BAgraph_dir(300,10,10);
% A scale-free network should have a power-law degree distribution. Verify
% by 
figure; hist(sum(A),20); xlabel('Degree'); ylabel('Count');
[Nd, drivernodes,Nconfig] = ExactControllability(A,'plotting',1)
% There are Nd = 33 driver nodes and only 1 configuration. The identity of
% driver nodes is provided in the variable drivernodes.
% You will note that the drivernodes have very low in-degrees
% sum(A(:,drivernodes)

%% Example 5:
% Lastly, let's try a random undirected symmetric Erdos Reyni network of 300 nodes with 0.01
% probability of connection between any pair-wise nodes
clc
A = erdos_reyni(300,0.01);
[Nd, drivernodes,Nconfig] = ExactControllability(full(A),'plotting',1)
% There are Nd = 22 driver nodes and 16 different ways to choose 22 driver
% nodes. Note: as the network becomes less sparse, i.e. as the probability
% of connection incresease from 0.01, the number of driver nodes decreases.
